package Constants;

public class ServletConstants {
    public static final String CHAT_PARAMETER = "chat";
    public static final String USERNAME = "username";
    public static final String USER_NAME_ERROR = "username_error";

}
