package CandidatesPane;

public class UBoatCandidatesPaneController {
}
