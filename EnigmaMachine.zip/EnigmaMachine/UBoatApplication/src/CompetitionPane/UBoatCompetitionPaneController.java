package CompetitionPane;

import MainScene.MainUBoatScenePaneController;

public class UBoatCompetitionPaneController {
    private MainUBoatScenePaneController mainUBoatScenePaneController;

    public void setMainUBoatScenePaneController(MainUBoatScenePaneController mainUBoatScenePaneController) {
        this.mainUBoatScenePaneController = mainUBoatScenePaneController;
    }

}
