package LoginPane;

import MainScene.MainUBoatScenePaneController;

public class UBoatLoginPaneController {
    private MainUBoatScenePaneController mainUBoatScenePaneController;

    public void setMainUBoatScenePaneController(MainUBoatScenePaneController mainUBoatScenePaneController) {
        this.mainUBoatScenePaneController = mainUBoatScenePaneController;
    }

}
