package Engine;

import ConsoleUserInterface.ConsoleUserInterface;

public interface ActivateOperation {
    public void activate(ConsoleUserInterface consoleUserInterface);
}
