package Engine.StatisticsAndHistory;

import java.io.Serializable;

public enum StringFormatType implements Serializable {
    ORIGINAL_STRING() ,
    ENCRYPTED_STRING();
}
