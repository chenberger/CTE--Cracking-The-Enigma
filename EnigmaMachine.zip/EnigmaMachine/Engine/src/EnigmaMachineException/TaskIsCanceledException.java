package EnigmaMachineException;

public class TaskIsCanceledException extends RuntimeException{
}
