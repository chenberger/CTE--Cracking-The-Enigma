package BruteForce;

public interface SetTask {
    public void setTask(TasksManager tasksManager) throws Exception;
}
