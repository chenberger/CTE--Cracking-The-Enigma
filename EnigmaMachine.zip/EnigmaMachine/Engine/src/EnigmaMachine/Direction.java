package EnigmaMachine;

import java.io.Serializable;

public enum Direction implements Serializable {
    FORWARD, BACKWARD;
}
