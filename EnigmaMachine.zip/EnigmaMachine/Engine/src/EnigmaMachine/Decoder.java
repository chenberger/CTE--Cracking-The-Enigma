package EnigmaMachine;

public interface Decoder {
    public int decode(int inputCharIndex, Direction direction);
}
